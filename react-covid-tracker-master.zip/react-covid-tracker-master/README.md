# COVID-19 Tracker

## Introduction

This is a website that provides real-time data on Covid cases worldwide and also country-wise. Users can view the same on a map as well.

## Its live at

https://vineet39.github.io/react-covid-tracker/

## Tools, languages and frameworks used 
ReactJS, HTML, CSS, Material-UI, API: https://disease.sh/v3/covid-19














